from app import ai

# Asking the user for 2 questions
# 1. Consult the book
# 2. Create a new recipe

choice = input("1. Consult the book\n2. Create a new recipe\nChoose an action 1 or 2: ")
print(choice)

#ai.recipe(["ingredients"], "instructions")

print(ai)
# Do the project here 
# New line
