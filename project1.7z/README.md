# Installing OpenAI package 
`pip install openai`
